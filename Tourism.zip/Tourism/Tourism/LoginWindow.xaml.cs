﻿using Npgsql;
using System;
using System.Windows;
using System.Windows.Controls;
using Tourism.Data;

namespace Tourism
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void ShowPasswordCheckBox_Changed(
            object sender, RoutedEventArgs e)
        {
            if (VisiblePasswordBox == null ||
                PasswordInput == null)
                return;

            if (ShowPasswordCheckBox.IsChecked == true)
            {
                VisiblePasswordBox.Text = PasswordInput.Password;
                VisiblePasswordBox.Visibility = Visibility.Visible;
                PasswordInput.Visibility = Visibility.Collapsed;
                VisiblePasswordBox.CaretIndex =
                    VisiblePasswordBox.Text.Length;
                VisiblePasswordBox.Focus();
            }
            else
            {
                PasswordInput.Password = VisiblePasswordBox.Text;
                PasswordInput.Visibility = Visibility.Visible;
                VisiblePasswordBox.Visibility = Visibility.Collapsed;
                PasswordInput.Focus();
            }
        }

        private void LoginButton_Click(
            object sender, RoutedEventArgs e)
        {
            ErrorText.Visibility = Visibility.Collapsed;

            string username = UsernameBox.Text.Trim();

            string password = ShowPasswordCheckBox.IsChecked == true
                ? VisiblePasswordBox.Text
                : PasswordInput.Password;

            if (string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrEmpty(password))
            {
                ShowError("Введите логин и пароль.");
                return;
            }

            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    const string sql = @"
                        SELECT user_id, username, password_hash, role
                        FROM users
                        WHERE username = @username
                          AND is_active = TRUE;";

                    using (var command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue(
                            "username", username);

                        using (var reader = command.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                ShowError("Неверный логин или пароль.");
                                return;
                            }

                            long userId = reader.GetInt64(0);
                            string dbUsername = reader.GetString(1);
                            string passwordHash = reader.GetString(2);
                            string role = reader.GetString(3);

                            if (!PasswordHasher.VerifyPassword(
                                password, passwordHash))
                            {
                                ShowError(
                                    "Неверный логин или пароль.");
                                return;
                            }

                            var mainWindow = new MainWindow(
                                userId, dbUsername, role);

                            Application.Current.MainWindow = mainWindow;
                            mainWindow.Show();
                            Close();
                        }
                    }
                }
            }
            catch (NpgsqlException)
            {
                ShowError(
                    "Не удалось подключиться к базе данных. " +
                    "Проверь подключение PostgreSQL.");
            }
            catch (Exception)
            {
                ShowError(
                    "Произошла ошибка при входе. Попробуйте ещё раз.");
            }
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorText.Visibility = Visibility.Visible;
        }
    }
}
