﻿
using Npgsql;
using Tourism.Data;

namespace Tourism.Data
{
    public static class DemoAccountSetup
    {
        public static void Initialize()
        {
            using (var connection = Database.GetConnection())
            {
                connection.Open();

                SetPassword(connection, "admin", "Admin123!");
                SetPassword(connection, "student", "Student123!");
            }
        }

        private static void SetPassword(
            NpgsqlConnection connection,
            string username,
            string password)
        {
            string hash = PasswordHasher.HashPassword(password);

            const string sql = @"
                UPDATE users
                SET password_hash = @hash
                WHERE username = @username
                  AND password_hash = 'DEMO_HASH_CHANGE_BEFORE_USE';";

            using (var command = new NpgsqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("hash", hash);
                command.Parameters.AddWithValue("username", username);
                command.ExecuteNonQuery();
            }
        }
    }
}
