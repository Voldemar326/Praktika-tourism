﻿// Файл: AdminManagementWindow.xaml.cs
using System.Windows;

namespace Tourism
{
    public partial class AdminManagementWindow : Window
    {
        public AdminManagementWindow()
        {
            InitializeComponent();
        }

        private void CountriesButton_Click(object sender, RoutedEventArgs e)
        {
            new CountryManagementWindow { Owner = this }.ShowDialog();
        }

        private void AttractionsButton_Click(object sender, RoutedEventArgs e)
        {
            new AttractionManagementWindow { Owner = this }.ShowDialog();
        }

        private void UsersButton_Click(object sender, RoutedEventArgs e)
        {
            new UserManagementWindow { Owner = this }.ShowDialog();
        }
    }
}