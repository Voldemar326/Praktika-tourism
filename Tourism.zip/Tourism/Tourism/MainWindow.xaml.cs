﻿
using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Tourism.Data;
using static Tourism.TripEditWindow;

namespace Tourism
{
    public class TripItem
    {
        public long TripId { get; set; }

        public string TripName { get; set; }

        public string Description { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string Status { get; set; }

        public string Countries { get; set; }

        public string Attractions { get; set; }

        public string StatusDisplay
        {
            get
            {
                switch (Status)
                {
                    case "planned":
                        return "Запланировано";

                    case "in_progress":
                        return "В процессе";

                    case "completed":
                        return "Завершено";

                    case "cancelled":
                        return "Отменено";

                    default:
                        return Status;
                }
            }
        }
    }

    public partial class MainWindow : Window
    {
        private readonly long _userId;
        private readonly string _username;
        private readonly string _role;

        private readonly ObservableCollection<TripItem> _trips =
            new ObservableCollection<TripItem>();

        private ICollectionView _tripsView;

        public MainWindow(long userId, string username, string role)
        {
            InitializeComponent();

            _userId = userId;
            _username = username;
            _role = role;

            TripsGrid.ItemsSource = _trips;
            _tripsView = CollectionViewSource.GetDefaultView(_trips);
            _tripsView.Filter = FilterTrip;

            UserInfoText.Text = "Пользователь: " + _username +
                " | Роль: " +
                (_role == "admin" ? "Администратор" : "Пользователь");

            LoadTrips();
        }


        private void SaveTripCountries(
            NpgsqlConnection connection,
            NpgsqlTransaction transaction,
            long tripId,
            List<CountryItem> selectedCountries)
        {
            // Temporarily move existing positions to a high positive range.
            using (var command = new NpgsqlCommand(
                @"UPDATE trip_countries
          SET visit_order = visit_order + 1000000
          WHERE trip_id = @trip_id;",
                connection,
                transaction))
            {
                command.Parameters.AddWithValue("trip_id", tripId);
                command.ExecuteNonQuery();
            }

            var selectedIds = selectedCountries
                .Select(c => c.CountryId)
                .ToList();

            // Remove countries that are no longer selected.
            if (selectedIds.Count > 0)
            {
                using (var command = new NpgsqlCommand(
                    @"DELETE FROM trip_countries
              WHERE trip_id = @trip_id
                AND country_id <> ALL(@country_ids);",
                    connection,
                    transaction))
                {
                    command.Parameters.AddWithValue("trip_id", tripId);
                    command.Parameters.AddWithValue(
                        "country_ids",
                        selectedIds.ToArray());

                    command.ExecuteNonQuery();
                }
            }
            else
            {
                using (var command = new NpgsqlCommand(
                    @"DELETE FROM trip_countries
              WHERE trip_id = @trip_id;",
                    connection,
                    transaction))
                {
                    command.Parameters.AddWithValue("trip_id", tripId);
                    command.ExecuteNonQuery();
                }

                return;
            }

            // Assign the final positions starting from 1.
            for (int i = 0; i < selectedCountries.Count; i++)
            {
                using (var command = new NpgsqlCommand(
                    @"UPDATE trip_countries
              SET visit_order = @visit_order
              WHERE trip_id = @trip_id
                AND country_id = @country_id;",
                    connection,
                    transaction))
                {
                    command.Parameters.AddWithValue("trip_id", tripId);
                    command.Parameters.AddWithValue(
                        "country_id",
                        selectedCountries[i].CountryId);
                    command.Parameters.AddWithValue("visit_order", i + 1);

                    int updated = command.ExecuteNonQuery();

                    if (updated == 0)
                    {
                        using (var insertCommand = new NpgsqlCommand(
                            @"INSERT INTO trip_countries
                        (trip_id, country_id, visit_order)
                      VALUES
                        (@trip_id, @country_id, @visit_order);",
                            connection,
                            transaction))
                        {
                            insertCommand.Parameters.AddWithValue("trip_id", tripId);
                            insertCommand.Parameters.AddWithValue(
                                "country_id",
                                selectedCountries[i].CountryId);
                            insertCommand.Parameters.AddWithValue(
                                "visit_order",
                                i + 1);

                            insertCommand.ExecuteNonQuery();
                        }
                    }
                }
            }
        }


        private void SyncTripStopsWithCountries(
            NpgsqlConnection connection,
            NpgsqlTransaction transaction,
            long tripId,
            List<CountryItem> selectedCountries)
        {
            var countryIds = selectedCountries
                .Select(c => c.CountryId)
                .ToArray();

            // Remove stops belonging to countries no longer selected.
            using (var command = new NpgsqlCommand(
                @"DELETE FROM trip_stops ts
          USING attractions a
          WHERE ts.attraction_id = a.attraction_id
            AND ts.trip_id = @trip_id
            AND NOT (a.country_id = ANY(@country_ids));",
                connection,
                transaction))
            {
                command.Parameters.AddWithValue("trip_id", tripId);
                command.Parameters.AddWithValue("country_ids", countryIds);
                command.ExecuteNonQuery();
            }

            // Add attractions from selected countries that are not in the trip yet.
            using (var command = new NpgsqlCommand(
                @"INSERT INTO trip_stops (trip_id, attraction_id, stop_order)
          SELECT
              @trip_id,
              a.attraction_id,
              COALESCE(
                  (SELECT MAX(ts.stop_order)
                   FROM trip_stops ts
                   WHERE ts.trip_id = @trip_id),
                  0
              ) + ROW_NUMBER() OVER (
                  ORDER BY a.country_id, a.attraction_name
              )::integer
          FROM attractions a
          WHERE a.country_id = ANY(@country_ids)
            AND NOT EXISTS (
                SELECT 1
                FROM trip_stops ts
                WHERE ts.trip_id = @trip_id
                  AND ts.attraction_id = a.attraction_id
            )
          ORDER BY a.country_id, a.attraction_name;",
                connection,
                transaction))
            {
                command.Parameters.AddWithValue("trip_id", tripId);
                command.Parameters.AddWithValue("country_ids", countryIds);
                command.ExecuteNonQuery();
            }
        }


        private bool FilterTrip(object item)
        {
            TripItem trip = item as TripItem;

            if (trip == null)
                return false;

            string search = SearchBox.Text.Trim();

            if (!string.IsNullOrEmpty(search))
            {
                bool found =
                    (trip.TripName ?? "").IndexOf(
                        search, StringComparison.OrdinalIgnoreCase) >= 0
                    ||
                    (trip.Description ?? "").IndexOf(
                        search, StringComparison.OrdinalIgnoreCase) >= 0;

                if (!found)
                    return false;
            }

            ComboBoxItem selected =
                StatusFilter.SelectedItem as ComboBoxItem;

            string selectedStatus = selected == null
                ? ""
                : Convert.ToString(selected.Tag);

            if (!string.IsNullOrEmpty(selectedStatus) &&
                trip.Status != selectedStatus)
                return false;

            return true;
        }

        private void SearchBox_TextChanged(
            object sender, TextChangedEventArgs e)
        {
            if (_tripsView != null)
            {
                _tripsView.Refresh();
                UpdateStatusText();
            }
        }

        private void StatusFilter_SelectionChanged(
            object sender, SelectionChangedEventArgs e)
        {
            if (_tripsView != null)
            {
                _tripsView.Refresh();
                UpdateStatusText();
            }
        }

        private void UpdateStatusText()
        {
            if (_tripsView != null)
                StatusText.Text = "Показано путешествий: " +
                    _tripsView.Cast<object>().Count();
        }

        private void LoadTrips()
        {
            _trips.Clear();
            StatusText.Text = "Загрузка путешествий...";

            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    string sql = @"
                SELECT
                    t.trip_id,
                    t.trip_name,
                    t.description,
                    t.start_date,
                    t.end_date,
                    t.status,

                    COALESCE((
                        SELECT string_agg(
                            c.country_name,
                            ', ' ORDER BY tc.visit_order
                        )
                        FROM trip_countries tc
                        JOIN countries c
                            ON c.country_id = tc.country_id
                        WHERE tc.trip_id = t.trip_id
                    ), '') AS countries,

                    COALESCE((
                        SELECT string_agg(
                            a.attraction_name ||
                            CASE
                                WHEN a.city IS NOT NULL
                                     AND a.city <> ''
                                THEN ' (' || a.city || ')'
                                ELSE ''
                            END,
                            ', ' ORDER BY ts.stop_order
                        )
                        FROM trip_stops ts
                        JOIN attractions a
                            ON a.attraction_id = ts.attraction_id
                        WHERE ts.trip_id = t.trip_id
                    ), '') AS attractions

                FROM trips t
                " + (_role == "admin"
                            ? ""
                            : "WHERE t.user_id = @user_id ") + @"
                ORDER BY t.created_at DESC;";

                    using (var command = new NpgsqlCommand(sql, connection))
                    {
                        if (_role != "admin")
                        {
                            command.Parameters.Add(
                                "user_id",
                                NpgsqlDbType.Bigint
                            ).Value = _userId;
                        }

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _trips.Add(new TripItem
                                {
                                    TripId = reader.GetInt64(0),
                                    TripName = reader.GetString(1),

                                    Description = reader.IsDBNull(2)
                                        ? ""
                                        : reader.GetString(2),

                                    StartDate = reader.GetDateTime(3),
                                    EndDate = reader.GetDateTime(4),
                                    Status = reader.GetString(5),
                                    Countries = reader.GetString(6),
                                    Attractions = reader.GetString(7)
                                });
                            }
                        }
                    }
                }

                _tripsView.Refresh();
                UpdateStatusText();
            }
            catch (NpgsqlException ex)
            {
                StatusText.Text = "Ошибка загрузки путешествий.";

                MessageBox.Show(
                    "Не удалось загрузить данные из PostgreSQL.\n\n"
                    + ex.Message,
                    "Ошибка базы данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new TripEditWindow
            {
                Owner = this
            };

            if (editWindow.ShowDialog() != true)
                return;

            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    using (var transaction = connection.BeginTransaction())
                    {
                        long tripId;

                        using (var command = new NpgsqlCommand(
                            @"INSERT INTO trips
                        (user_id, trip_name, description,
                         start_date, end_date, status)
                      VALUES
                        (@user_id, @trip_name, @description,
                         @start_date, @end_date, @status)
                      RETURNING trip_id;",
                            connection,
                            transaction))
                        {
                            command.Parameters.AddWithValue("user_id", _userId);
                            command.Parameters.AddWithValue(
                                "trip_name",
                                editWindow.TripName);
                            command.Parameters.AddWithValue(
                                "description",
                                string.IsNullOrWhiteSpace(editWindow.TripDescription)
                                    ? (object)DBNull.Value
                                    : editWindow.TripDescription);
                            command.Parameters.AddWithValue(
                                "start_date",
                                editWindow.TripStartDate);
                            command.Parameters.AddWithValue(
                                "end_date",
                                editWindow.TripEndDate);
                            command.Parameters.AddWithValue(
                                "status",
                                editWindow.TripStatus);

                            tripId = (long)command.ExecuteScalar();
                        }

                        SaveTripCountries(
                            connection,
                            transaction,
                            tripId,
                            editWindow.SelectedCountries);

                        AddCountryAttractionsToNewTrip(
                            connection,
                            transaction,
                            tripId,
                            editWindow.SelectedCountries);

                        transaction.Commit();
                    }
                }

                LoadTrips();
                StatusText.Text = "Путешествие добавлено.";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось создать путешествие:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void EditButton_Click(
            object sender, RoutedEventArgs e)
        {
            EditSelectedTrip();
        }

        private void TripsGrid_MouseDoubleClick(
            object sender,
            System.Windows.Input.MouseButtonEventArgs e)
        {
            if (TripsGrid.SelectedItem != null)
                EditSelectedTrip();
        }

        private void EditSelectedTrip()
        {
            TripItem trip = TripsGrid.SelectedItem as TripItem;

            if (trip == null)
            {
                MessageBox.Show("Выбери путешествие для редактирования.");
                return;
            }

            var editWindow = new TripEditWindow(trip)
            {
                Owner = this
            };

            if (editWindow.ShowDialog() != true)
                return;

            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    using (var transaction = connection.BeginTransaction())
                    {
                        using (var command = new NpgsqlCommand(
                            @"UPDATE trips
                      SET trip_name = @trip_name,
                          description = @description,
                          start_date = @start_date,
                          end_date = @end_date,
                          status = @status
                      WHERE trip_id = @trip_id
                        AND (@is_admin = TRUE OR user_id = @user_id);",
                            connection,
                            transaction))
                        {
                            command.Parameters.AddWithValue(
                                "trip_id",
                                trip.TripId);
                            command.Parameters.AddWithValue(
                                "trip_name",
                                editWindow.TripName);
                            command.Parameters.AddWithValue(
                                "description",
                                string.IsNullOrWhiteSpace(editWindow.TripDescription)
                                    ? (object)DBNull.Value
                                    : editWindow.TripDescription);
                            command.Parameters.AddWithValue(
                                "start_date",
                                editWindow.TripStartDate);
                            command.Parameters.AddWithValue(
                                "end_date",
                                editWindow.TripEndDate);
                            command.Parameters.AddWithValue(
                                "status",
                                editWindow.TripStatus);
                            command.Parameters.AddWithValue(
                                "is_admin",
                                _role == "admin");
                            command.Parameters.AddWithValue("user_id", _userId);

                            if (command.ExecuteNonQuery() == 0)
                            {
                                throw new InvalidOperationException(
                                    "Путешествие не найдено или у вас нет прав на его изменение.");
                            }
                        }


                        SaveTripCountries(
                            connection,
                            transaction,
                            trip.TripId,
                            editWindow.SelectedCountries);

                        SyncTripStopsWithCountries(
                            connection,
                            transaction,
                            trip.TripId,
                            editWindow.SelectedCountries);


                        transaction.Commit();
                    }
                }

                LoadTrips();
                StatusText.Text = "Путешествие обновлено.";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось обновить путешествие:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void DeleteButton_Click(
            object sender, RoutedEventArgs e)
        {
            TripItem trip = TripsGrid.SelectedItem as TripItem;

            if (trip == null)
            {
                MessageBox.Show(
                    "Сначала выбери путешествие в таблице.",
                    "Удаление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "Удалить путешествие \"" + trip.TripName + "\"?\n\n" +
                "Это действие нельзя отменить.",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes)
                return;

            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    string sql = _role == "admin"
                        ? "DELETE FROM trips WHERE trip_id = @trip_id;"
                        : "DELETE FROM trips WHERE trip_id = @trip_id " +
                          "AND user_id = @user_id;";

                    using (var command =
                        new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.Add(
                            "trip_id", NpgsqlDbType.Bigint).Value =
                            trip.TripId;

                        if (_role != "admin")
                        {
                            command.Parameters.Add(
                                "user_id", NpgsqlDbType.Bigint).Value =
                                _userId;
                        }

                        int affected = command.ExecuteNonQuery();

                        if (affected == 0)
                        {
                            MessageBox.Show(
                                "Путешествие не найдено или у тебя нет " +
                                "прав на его удаление.",
                                "Удаление не выполнено",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                        }
                    }
                }

                LoadTrips();
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show(
                    "Не удалось удалить путешествие.\n\n" + ex.Message,
                    "Ошибка базы данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(
            object sender, RoutedEventArgs e)
        {
            LoadTrips();
        }

        private void ManageDataButton_Click(object sender, RoutedEventArgs e)
        {
            if (_role != "admin")
            {
                MessageBox.Show("Доступ разрешён только администратору.");
                return;
            }

            var window = new AdminManagementWindow
            {
                Owner = this
            };

            window.ShowDialog();

            LoadTrips();
        }

        private void AddCountryAttractionsToNewTrip(
    NpgsqlConnection connection,
    NpgsqlTransaction transaction,
    long tripId,
    List<CountryItem> selectedCountries)
        {
            if (selectedCountries == null || selectedCountries.Count == 0)
                return;

            using (var command = new NpgsqlCommand(@"
        INSERT INTO trip_stops
            (trip_id, attraction_id, stop_order)
        SELECT
            @trip_id,
            x.attraction_id,
            ROW_NUMBER() OVER (
                ORDER BY x.country_position, x.attraction_name
            )::integer
        FROM (
            SELECT
                a.attraction_id,
                a.attraction_name,
                array_position(
                    @country_ids,
                    tc.country_id
                ) AS country_position
            FROM trip_countries tc
            JOIN attractions a
                ON a.country_id = tc.country_id
            WHERE tc.trip_id = @trip_id
              AND NOT EXISTS (
                  SELECT 1
                  FROM trip_stops existing
                  WHERE existing.trip_id = @trip_id
                    AND existing.attraction_id = a.attraction_id
              )
        ) x
        ORDER BY x.country_position, x.attraction_name;",
                connection,
                transaction))
            {
                command.Parameters.AddWithValue("trip_id", tripId);

                command.Parameters.AddWithValue(
                    "country_ids",
                    selectedCountries.Select(c => c.CountryId).ToArray());

                command.ExecuteNonQuery();
            }
        }

        private static void AddTripParameters(
            NpgsqlCommand command, TripEditWindow dialog)
        {
            command.Parameters.Add(
                "trip_name", NpgsqlDbType.Varchar).Value =
                dialog.TripName;

            command.Parameters.Add(
                "description", NpgsqlDbType.Text).Value =
                string.IsNullOrWhiteSpace(dialog.TripDescription)
                    ? (object)DBNull.Value
                    : dialog.TripDescription;

            command.Parameters.Add(
                "start_date", NpgsqlDbType.Date).Value =
                dialog.TripStartDate.Date;

            command.Parameters.Add(
                "end_date", NpgsqlDbType.Date).Value =
                dialog.TripEndDate.Date;

            command.Parameters.Add(
                "status", NpgsqlDbType.Varchar).Value =
                dialog.TripStatus;
        }
    }
}
