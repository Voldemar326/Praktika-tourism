﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using Npgsql;
using Tourism.Data;

namespace Tourism
{
    public class AttractionRecord
    {
        public long AttractionId { get; set; }
        public long CountryId { get; set; }
        public string CountryName { get; set; }
        public string AttractionName { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public string Description { get; set; }
        public int? EstimatedVisitMinutes { get; set; }
        public decimal? EntranceFee { get; set; }
    }

    public partial class AttractionManagementWindow : Window
    {
        private readonly ObservableCollection<AttractionRecord> _items =
            new ObservableCollection<AttractionRecord>();

        public AttractionManagementWindow()
        {
            InitializeComponent();
            AttractionsGrid.ItemsSource = _items;
            LoadAttractions();
        }

        private void LoadAttractions()
        {
            try
            {
                _items.Clear();

                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(@"
                        SELECT a.attraction_id, a.country_id, c.country_name,
                               a.attraction_name, a.city, a.address,
                               a.description, a.estimated_visit_minutes,
                               a.entrance_fee
                        FROM attractions a
                        JOIN countries c ON c.country_id = a.country_id
                        ORDER BY c.country_name, a.attraction_name;",
                        connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _items.Add(new AttractionRecord
                            {
                                AttractionId = reader.GetInt64(0),
                                CountryId = reader.GetInt64(1),
                                CountryName = reader.GetString(2),
                                AttractionName = reader.GetString(3),
                                City = reader.IsDBNull(4) ? "" : reader.GetString(4),
                                Address = reader.IsDBNull(5) ? "" : reader.GetString(5),
                                Description = reader.IsDBNull(6) ? "" : reader.GetString(6),
                                EstimatedVisitMinutes = reader.IsDBNull(7)
                                    ? (int?)null : reader.GetInt32(7),
                                EntranceFee = reader.IsDBNull(8)
                                    ? (decimal?)null : reader.GetDecimal(8)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Не удалось загрузить достопримечательности", ex);
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new AttractionEditWindow { Owner = this };

            if (dialog.ShowDialog() == true)
                SaveAttraction(null, dialog);
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = AttractionsGrid.SelectedItem as AttractionRecord;

            if (selected == null)
            {
                MessageBox.Show("Выбери достопримечательность.");
                return;
            }

            var dialog = new AttractionEditWindow(selected) { Owner = this };

            if (dialog.ShowDialog() == true)
                SaveAttraction(selected.AttractionId, dialog);
        }

        private void SaveAttraction(long? id, AttractionEditWindow dialog)
        {
            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    string sql = id.HasValue
                        ? @"UPDATE attractions
                            SET country_id = @country_id,
                                attraction_name = @name,
                                city = @city,
                                address = @address,
                                description = @description,
                                estimated_visit_minutes = @minutes,
                                entrance_fee = @fee
                            WHERE attraction_id = @id;"
                        : @"INSERT INTO attractions
                               (country_id, attraction_name, city, address,
                                description, estimated_visit_minutes, entrance_fee)
                            VALUES
                               (@country_id, @name, @city, @address,
                                @description, @minutes, @fee);";

                    using (var command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("country_id", dialog.CountryId);
                        command.Parameters.AddWithValue("name", dialog.AttractionName);
                        command.Parameters.AddWithValue("city", DbValue(dialog.City));
                        command.Parameters.AddWithValue("address", DbValue(dialog.Address));
                        command.Parameters.AddWithValue("description", DbValue(dialog.Description));
                        command.Parameters.AddWithValue(
                            "minutes",
                            dialog.EstimatedVisitMinutes.HasValue
                                ? (object)dialog.EstimatedVisitMinutes.Value
                                : DBNull.Value);
                        command.Parameters.AddWithValue(
                            "fee",
                            dialog.EntranceFee.HasValue
                                ? (object)dialog.EntranceFee.Value
                                : DBNull.Value);

                        if (id.HasValue)
                            command.Parameters.AddWithValue("id", id.Value);

                        command.ExecuteNonQuery();
                    }
                }

                LoadAttractions();
            }
            catch (Exception ex)
            {
                ShowError("Не удалось сохранить достопримечательность", ex);
            }
        }

        private static object DbValue(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? (object)DBNull.Value
                : value.Trim();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = AttractionsGrid.SelectedItem as AttractionRecord;

            if (selected == null)
            {
                MessageBox.Show("Выбери достопримечательность.");
                return;
            }

            if (MessageBox.Show(
                "Удалить «" + selected.AttractionName + "»?",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            try
            {
                using (var connection = Database.GetConnection())
                using (var command = new NpgsqlCommand(
                    "DELETE FROM attractions WHERE attraction_id = @id;",
                    connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("id", selected.AttractionId);
                    command.ExecuteNonQuery();
                }

                LoadAttractions();
            }
            catch (Exception ex)
            {
                ShowError(
                    "Не удалось удалить место. Возможно, оно используется в путешествии",
                    ex);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadAttractions();
        }

        private void ShowError(string message, Exception ex)
        {
            MessageBox.Show(
                message + ":\n" + ex.Message,
                "Ошибка",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}