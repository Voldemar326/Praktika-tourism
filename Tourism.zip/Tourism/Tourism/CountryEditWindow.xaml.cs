﻿using System.Windows;

namespace Tourism
{
    public partial class CountryEditWindow : Window
    {
        public string CountryName { get; private set; }
        public string Capital { get; private set; }
        public string Description { get; private set; }

        public CountryEditWindow()
        {
            InitializeComponent();
        }

        public CountryEditWindow(CountryRecord country) : this()
        {
            TitleText.Text = "Редактирование страны";
            CountryNameBox.Text = country.CountryName;
            CapitalBox.Text = country.Capital;
            DescriptionBox.Text = country.Description;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            CountryName = CountryNameBox.Text.Trim();
            Capital = CapitalBox.Text.Trim();
            Description = DescriptionBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(CountryName))
            {
                ValidationText.Text = "Укажи название страны.";
                return;
            }

            DialogResult = true;
        }
    }
}