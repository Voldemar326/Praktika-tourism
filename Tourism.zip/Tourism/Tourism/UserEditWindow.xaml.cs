﻿using System;
using System.Net.Mail;
using System.Windows;
using System.Windows.Controls;

namespace Tourism
{
    public partial class UserEditWindow : Window
    {
        private readonly bool _isNew;

        public string Username { get; private set; }
        public string Email { get; private set; }
        public string Password { get; private set; }
        public string Role { get; private set; }
        public bool IsActive { get; private set; }

        public UserEditWindow()
        {
            InitializeComponent();
            _isNew = true;
        }

        public UserEditWindow(UserRecord user) : this()
        {
            _isNew = false;

            TitleText.Text = "Редактирование пользователя";
            UsernameBox.Text = user.Username;
            EmailBox.Text = user.Email;
            ActiveCheckBox.IsChecked = user.IsActive;

            foreach (ComboBoxItem item in RoleBox.Items)
            {
                if (Convert.ToString(item.Tag) == user.Role)
                {
                    RoleBox.SelectedItem = item;
                    break;
                }
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            ValidationText.Text = "";

            string username = UsernameBox.Text.Trim();
            string email = EmailBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username))
            {
                ValidationText.Text = "Укажи логин.";
                return;
            }

            if (string.IsNullOrWhiteSpace(email))
            {
                ValidationText.Text = "Укажи email.";
                return;
            }

            try
            {
                new MailAddress(email);
            }
            catch
            {
                ValidationText.Text = "Email имеет неверный формат.";
                return;
            }

            if (_isNew && string.IsNullOrWhiteSpace(password))
            {
                ValidationText.Text = "Для нового пользователя нужен пароль.";
                return;
            }

            if (!string.IsNullOrWhiteSpace(password) && password.Length < 6)
            {
                ValidationText.Text = "Пароль должен содержать не менее 6 символов.";
                return;
            }

            var roleItem = RoleBox.SelectedItem as ComboBoxItem;

            if (roleItem == null)
            {
                ValidationText.Text = "Выбери роль.";
                return;
            }

            Username = username;
            Email = email;
            Password = password;
            Role = Convert.ToString(roleItem.Tag);
            IsActive = ActiveCheckBox.IsChecked == true;

            DialogResult = true;
        }
    }
}