﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using Npgsql;
using Tourism.Data;

namespace Tourism
{
    public partial class AttractionEditWindow : Window
    {
        public long CountryId { get; private set; }
        public string AttractionName { get; private set; }
        public string City { get; private set; }
        public string Address { get; private set; }
        public string Description { get; private set; }
        public int? EstimatedVisitMinutes { get; private set; }
        public decimal? EntranceFee { get; private set; }

        public AttractionEditWindow()
        {
            InitializeComponent();
            LoadCountries();
        }

        public AttractionEditWindow(AttractionRecord item) : this()
        {
            TitleText.Text = "Редактирование достопримечательности";
            AttractionNameBox.Text = item.AttractionName;
            CityBox.Text = item.City;
            AddressBox.Text = item.Address;
            DescriptionBox.Text = item.Description;

            MinutesBox.Text = item.EstimatedVisitMinutes.HasValue
                ? item.EstimatedVisitMinutes.Value.ToString()
                : "";

            FeeBox.Text = item.EntranceFee.HasValue
                ? item.EntranceFee.Value.ToString(CultureInfo.CurrentCulture)
                : "";

            CountryBox.SelectedValue = item.CountryId;
        }

        private void LoadCountries()
        {
            try
            {
                var countries = new List<CountryItem>();

                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(
                        @"SELECT country_id, country_name
                          FROM countries ORDER BY country_name;",
                        connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            countries.Add(new CountryItem
                            {
                                CountryId = reader.GetInt64(0),
                                CountryName = reader.GetString(1)
                            });
                        }
                    }
                }

                CountryBox.ItemsSource = countries;
                CountryBox.SelectedValuePath = "CountryId";

                if (countries.Count > 0)
                    CountryBox.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось загрузить страны:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            ValidationText.Text = "";

            var country = CountryBox.SelectedItem as CountryItem;

            if (country == null)
            {
                ValidationText.Text = "Сначала добавь страну.";
                return;
            }

            string name = AttractionNameBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                ValidationText.Text = "Укажи название места.";
                return;
            }

            int minutes;
            int? parsedMinutes = null;

            if (!string.IsNullOrWhiteSpace(MinutesBox.Text))
            {
                if (!int.TryParse(MinutesBox.Text.Trim(), out minutes) || minutes < 0)
                {
                    ValidationText.Text = "Время должно быть целым числом от 0.";
                    return;
                }

                parsedMinutes = minutes;
            }

            decimal fee;
            decimal? parsedFee = null;

            if (!string.IsNullOrWhiteSpace(FeeBox.Text))
            {
                bool parsed =
                    decimal.TryParse(FeeBox.Text.Trim(),
                        NumberStyles.Number, CultureInfo.CurrentCulture, out fee)
                    || decimal.TryParse(FeeBox.Text.Trim(),
                        NumberStyles.Number, CultureInfo.InvariantCulture, out fee);

                if (!parsed || fee < 0)
                {
                    ValidationText.Text = "Проверь стоимость входа.";
                    return;
                }

                parsedFee = fee;
            }

            CountryId = country.CountryId;
            AttractionName = name;
            City = CityBox.Text.Trim();
            Address = AddressBox.Text.Trim();
            Description = DescriptionBox.Text.Trim();
            EstimatedVisitMinutes = parsedMinutes;
            EntranceFee = parsedFee;

            DialogResult = true;
        }
    }
}