﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using Npgsql;
using Tourism.Data;

namespace Tourism
{
    public class UserRecord
    {
        public long UserId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public partial class UserManagementWindow : Window
    {
        private readonly ObservableCollection<UserRecord> _users =
            new ObservableCollection<UserRecord>();

        public UserManagementWindow()
        {
            InitializeComponent();
            UsersGrid.ItemsSource = _users;
            LoadUsers();
        }

        private void LoadUsers()
        {
            try
            {
                _users.Clear();

                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(
                        @"SELECT user_id, username, email, role,
                                 is_active, created_at
                          FROM users
                          ORDER BY username;",
                        connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _users.Add(new UserRecord
                            {
                                UserId = reader.GetInt64(0),
                                Username = reader.GetString(1),
                                Email = reader.GetString(2),
                                Role = reader.GetString(3),
                                IsActive = reader.GetBoolean(4),
                                CreatedAt = reader.GetDateTime(5)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Не удалось загрузить пользователей", ex);
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new UserEditWindow { Owner = this };

            if (dialog.ShowDialog() == true)
                SaveUser(null, dialog);
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = UsersGrid.SelectedItem as UserRecord;

            if (selected == null)
            {
                MessageBox.Show("Выбери пользователя.");
                return;
            }

            var dialog = new UserEditWindow(selected) { Owner = this };

            if (dialog.ShowDialog() == true)
                SaveUser(selected.UserId, dialog);
        }

        private void SaveUser(long? id, UserEditWindow dialog)
        {
            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    if (!id.HasValue)
                    {
                        using (var command = new NpgsqlCommand(@"
                            INSERT INTO users
                                (username, password_hash, email, role, is_active)
                            VALUES
                                (@username, @password_hash, @email, @role, @active);",
                            connection))
                        {
                            command.Parameters.AddWithValue("username", dialog.Username);
                            command.Parameters.AddWithValue(
                                "password_hash",
                                PasswordHasher.HashPassword(dialog.Password));
                            command.Parameters.AddWithValue("email", dialog.Email);
                            command.Parameters.AddWithValue("role", dialog.Role);
                            command.Parameters.AddWithValue("active", dialog.IsActive);

                            command.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        string sql = string.IsNullOrWhiteSpace(dialog.Password)
                            ? @"UPDATE users
                                SET username = @username,
                                    email = @email,
                                    role = @role,
                                    is_active = @active
                                WHERE user_id = @id;"
                            : @"UPDATE users
                                SET username = @username,
                                    email = @email,
                                    role = @role,
                                    is_active = @active,
                                    password_hash = @password_hash
                                WHERE user_id = @id;";

                        using (var command = new NpgsqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("username", dialog.Username);
                            command.Parameters.AddWithValue("email", dialog.Email);
                            command.Parameters.AddWithValue("role", dialog.Role);
                            command.Parameters.AddWithValue("active", dialog.IsActive);
                            command.Parameters.AddWithValue("id", id.Value);

                            if (!string.IsNullOrWhiteSpace(dialog.Password))
                            {
                                command.Parameters.AddWithValue(
                                    "password_hash",
                                    PasswordHasher.HashPassword(dialog.Password));
                            }

                            command.ExecuteNonQuery();
                        }
                    }
                }

                LoadUsers();
            }
            catch (Exception ex)
            {
                ShowError(
                    "Не удалось сохранить пользователя. Возможно, логин или email уже заняты.",
                    ex);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = UsersGrid.SelectedItem as UserRecord;

            if (selected == null)
            {
                MessageBox.Show("Выбери пользователя.");
                return;
            }

            if (MessageBox.Show(
                "Удалить пользователя «" + selected.Username + "»?",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            try
            {
                using (var connection = Database.GetConnection())
                using (var command = new NpgsqlCommand(
                    "DELETE FROM users WHERE user_id = @id;",
                    connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("id", selected.UserId);
                    command.ExecuteNonQuery();
                }

                LoadUsers();
            }
            catch (Exception ex)
            {
                ShowError(
                    "Не удалось удалить пользователя. Если у него есть путешествия, попробуй сначала деактивировать аккаунт.",
                    ex);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadUsers();
        }

        private void ShowError(string message, Exception ex)
        {
            MessageBox.Show(
                message + ":\n" + ex.Message,
                "Ошибка",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}