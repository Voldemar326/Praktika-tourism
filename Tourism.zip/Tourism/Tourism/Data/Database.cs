﻿
using Npgsql;

namespace Tourism.Data
{
    public static class Database
    {
        private const string ConnectionString =
            "Host=localhost;" +
            "Port=5432;" +
            "Database=postgres;" +
            "Username=postgres;" +
            "Password=987526;";

        public static NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(ConnectionString);
        }
    }
}
