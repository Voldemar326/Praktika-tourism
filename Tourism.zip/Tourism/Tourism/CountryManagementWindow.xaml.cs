﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using Npgsql;
using Tourism.Data;

namespace Tourism
{
    public class CountryRecord
    {
        public long CountryId { get; set; }
        public string CountryName { get; set; }
        public string Capital { get; set; }
        public string Description { get; set; }
    }

    public partial class CountryManagementWindow : Window
    {
        private readonly ObservableCollection<CountryRecord> _countries =
            new ObservableCollection<CountryRecord>();

        public CountryManagementWindow()
        {
            InitializeComponent();
            CountriesGrid.ItemsSource = _countries;
            LoadCountries();
        }

        private void LoadCountries()
        {
            try
            {
                _countries.Clear();

                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(
                        @"SELECT country_id, country_name, capital, description
                          FROM countries
                          ORDER BY country_name;",
                        connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _countries.Add(new CountryRecord
                            {
                                CountryId = reader.GetInt64(0),
                                CountryName = reader.GetString(1),
                                Capital = reader.IsDBNull(2) ? "" : reader.GetString(2),
                                Description = reader.IsDBNull(3) ? "" : reader.GetString(3)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Не удалось загрузить страны", ex);
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new CountryEditWindow { Owner = this };

            if (dialog.ShowDialog() == true)
            {
                SaveCountry(
                    null,
                    dialog.CountryName,
                    dialog.Capital,
                    dialog.Description);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = CountriesGrid.SelectedItem as CountryRecord;

            if (selected == null)
            {
                MessageBox.Show("Выбери страну.");
                return;
            }

            var dialog = new CountryEditWindow(selected) { Owner = this };

            if (dialog.ShowDialog() == true)
            {
                SaveCountry(
                    selected.CountryId,
                    dialog.CountryName,
                    dialog.Capital,
                    dialog.Description);
            }
        }

        private void SaveCountry(
            long? id,
            string name,
            string capital,
            string description)
        {
            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    string sql = id.HasValue
                        ? @"UPDATE countries
                            SET country_name = @name,
                                capital = @capital,
                                description = @description
                            WHERE country_id = @id;"
                        : @"INSERT INTO countries
                                (country_name, capital, description)
                            VALUES (@name, @capital, @description);";

                    using (var command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("name", name);
                        command.Parameters.AddWithValue(
                            "capital",
                            string.IsNullOrWhiteSpace(capital)
                                ? (object)DBNull.Value
                                : capital);
                        command.Parameters.AddWithValue(
                            "description",
                            string.IsNullOrWhiteSpace(description)
                                ? (object)DBNull.Value
                                : description);

                        if (id.HasValue)
                            command.Parameters.AddWithValue("id", id.Value);

                        command.ExecuteNonQuery();
                    }
                }

                LoadCountries();
            }
            catch (Exception ex)
            {
                ShowError("Не удалось сохранить страну", ex);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = CountriesGrid.SelectedItem as CountryRecord;

            if (selected == null)
            {
                MessageBox.Show("Выбери страну.");
                return;
            }

            if (MessageBox.Show(
                "Удалить страну «" + selected.CountryName +
                "»? Если она используется в маршрутах или достопримечательностях, удаление будет запрещено.",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            try
            {
                using (var connection = Database.GetConnection())
                using (var command = new NpgsqlCommand(
                    "DELETE FROM countries WHERE country_id = @id;",
                    connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("id", selected.CountryId);
                    command.ExecuteNonQuery();
                }

                LoadCountries();
            }

            catch (PostgresException ex) when (ex.SqlState == "23503")
            {
                MessageBox.Show(
                    "Невозможно удалить страну, так как она привязана " +
                    "к достопримечательностям.\n\n" +
                    "Сначала удалите связанные достопримечательности " +
                    "или перенесите их в другую страну.",
                    "Невозможно удалить страну",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось удалить страну:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }

        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadCountries();
        }

        private void ShowError(string message, Exception ex)
        {
            MessageBox.Show(
                message + ":\n" + ex.Message,
                "Ошибка",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}