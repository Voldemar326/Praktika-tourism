﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Npgsql;
using Tourism.Data;

namespace Tourism
{
    public class CountryItem
    {
        public long CountryId { get; set; }

        public string CountryName { get; set; }

        public override string ToString()
        {
            return CountryName;
        }
    }

    public partial class TripEditWindow : Window
    {
        public string TripName { get; private set; }

        public string TripDescription { get; private set; }

        public DateTime TripStartDate { get; private set; }

        public DateTime TripEndDate { get; private set; }

        public string TripStatus { get; private set; }

        public List<CountryItem> SelectedCountries { get; private set; }
            = new List<CountryItem>();

        private readonly long? _tripId;

        public TripEditWindow()
        {
            InitializeComponent();

            _tripId = null;

            StartDatePicker.SelectedDate = DateTime.Today;
            EndDatePicker.SelectedDate = DateTime.Today.AddDays(1);

            LoadCountries();
        }

        public TripEditWindow(TripItem trip) : this()
        {
            if (trip == null)
                return;

            _tripId = trip.TripId;

            WindowTitleText.Text = "Редактирование путешествия";

            TripNameBox.Text = trip.TripName;
            DescriptionBox.Text = trip.Description ?? "";

            StartDatePicker.SelectedDate = trip.StartDate;
            EndDatePicker.SelectedDate = trip.EndDate;

            foreach (ComboBoxItem item in TripStatusBox.Items)
            {
                if (Convert.ToString(item.Tag) == trip.Status)
                {
                    TripStatusBox.SelectedItem = item;
                    break;
                }
            }

            LoadSelectedCountries();
        }

        private void LoadCountries()
        {
            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(
                        @"SELECT country_id, country_name
                          FROM countries
                          ORDER BY country_name;",
                        connection))
                    using (var reader = command.ExecuteReader())
                    {
                        AvailableCountriesList.Items.Clear();

                        while (reader.Read())
                        {
                            AvailableCountriesList.Items.Add(
                                new CountryItem
                                {
                                    CountryId = reader.GetInt64(0),
                                    CountryName = reader.GetString(1)
                                });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось загрузить страны из базы данных:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void LoadSelectedCountries()
        {
            if (!_tripId.HasValue)
                return;

            try
            {
                using (var connection = Database.GetConnection())
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(
                        @"SELECT c.country_id, c.country_name
                          FROM trip_countries tc
                          JOIN countries c
                            ON c.country_id = tc.country_id
                          WHERE tc.trip_id = @trip_id
                          ORDER BY tc.visit_order;",
                        connection))
                    {
                        command.Parameters.AddWithValue(
                            "trip_id",
                            _tripId.Value);

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var country = new CountryItem
                                {
                                    CountryId = reader.GetInt64(0),
                                    CountryName = reader.GetString(1)
                                };

                                RouteCountriesList.Items.Add(country);

                                CountryItem availableCountry =
                                    AvailableCountriesList.Items
                                        .Cast<CountryItem>()
                                        .FirstOrDefault(c =>
                                            c.CountryId == country.CountryId);

                                if (availableCountry != null)
                                {
                                    AvailableCountriesList.Items.Remove(
                                        availableCountry);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось загрузить страны путешествия:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void AddCountryButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            var country =
                AvailableCountriesList.SelectedItem as CountryItem;

            if (country == null)
                return;

            AvailableCountriesList.Items.Remove(country);
            RouteCountriesList.Items.Add(country);

            RouteCountriesList.SelectedItem = country;
        }

        private void RemoveCountryButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            var country =
                RouteCountriesList.SelectedItem as CountryItem;

            if (country == null)
                return;

            RouteCountriesList.Items.Remove(country);

            AvailableCountriesList.Items.Add(country);

            SortAvailableCountries();

            AvailableCountriesList.SelectedItem =
                AvailableCountriesList.Items
                    .Cast<CountryItem>()
                    .FirstOrDefault(c =>
                        c.CountryId == country.CountryId);
        }

        private void MoveCountryUpButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            int index = RouteCountriesList.SelectedIndex;

            if (index <= 0)
                return;

            var country =
                (CountryItem)RouteCountriesList.Items[index];

            RouteCountriesList.Items.RemoveAt(index);
            RouteCountriesList.Items.Insert(index - 1, country);

            RouteCountriesList.SelectedIndex = index - 1;
        }

        private void MoveCountryDownButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            int index = RouteCountriesList.SelectedIndex;

            if (index < 0 ||
                index >= RouteCountriesList.Items.Count - 1)
            {
                return;
            }

            var country =
                (CountryItem)RouteCountriesList.Items[index];

            RouteCountriesList.Items.RemoveAt(index);
            RouteCountriesList.Items.Insert(index + 1, country);

            RouteCountriesList.SelectedIndex = index + 1;
        }

        private void SortAvailableCountries()
        {
            var countries = AvailableCountriesList.Items
                .Cast<CountryItem>()
                .OrderBy(c => c.CountryName)
                .ToList();

            AvailableCountriesList.Items.Clear();

            foreach (var country in countries)
            {
                AvailableCountriesList.Items.Add(country);
            }
        }

        private void SaveButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            ValidationText.Visibility = Visibility.Collapsed;

            string name = TripNameBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                ShowValidation("Введи название путешествия.");
                TripNameBox.Focus();
                return;
            }

            if (StartDatePicker.SelectedDate == null ||
                EndDatePicker.SelectedDate == null)
            {
                ShowValidation("Укажи дату начала и окончания.");
                return;
            }

            DateTime startDate =
                StartDatePicker.SelectedDate.Value.Date;

            DateTime endDate =
                EndDatePicker.SelectedDate.Value.Date;

            if (endDate < startDate)
            {
                ShowValidation(
                    "Дата окончания не может быть раньше даты начала.");
                return;
            }

            var selectedStatus =
                TripStatusBox.SelectedItem as ComboBoxItem;

            if (selectedStatus == null)
            {
                ShowValidation("Выбери статус путешествия.");
                return;
            }

            TripName = name;
            TripDescription = DescriptionBox.Text.Trim();
            TripStartDate = startDate;
            TripEndDate = endDate;
            TripStatus = Convert.ToString(selectedStatus.Tag);

            SelectedCountries = RouteCountriesList.Items
                .Cast<CountryItem>()
                .ToList();

            DialogResult = true;
        }

        private void ShowValidation(string message)
        {
            ValidationText.Text = message;
            ValidationText.Visibility = Visibility.Visible;
        }
    }
}
